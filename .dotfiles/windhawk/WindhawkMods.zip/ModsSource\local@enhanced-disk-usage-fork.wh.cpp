// ==WindhawkMod==
// @id              enhanced-disk-usage-fork
// @name            Enhanced Disk Usage - Fork
// @description     Enables the ability to customize the disk drive tiles in explorer, targeting the disk's usage bar, as well as the details that appear below.
// @version         1.2.0
// @author          bbmaster123
// @github          https://github.com/bbmaster123
// @include         explorer.exe
// @compilerOptions -lcomctl32 -lole32 -luuid -luser32 -lgdi32 -luxtheme -lshlwapi -lmsimg32 -lgdiplus
// ==/WindhawkMod==

// ==WindhawkModReadme==
/*
![Screenshot](https://raw.githubusercontent.com/bbmaster123/FWFU/refs/heads/main/Assets/screenshot.png)

Enables the ability to customize the disk drive tiles in explorer, targeting the disk's usage bar, as well
as the details that appear below.

- custom colors with transparency for disk usage, track (background/unused), and outline
- separate disk colors for when drive is near full
- linear gradient support with configurable direction
- rounded corners
- glossy overlay toggle option (for a more Windows Aero-ish looking aesthetic)
- height/width controls (inset) controls for disk bar and track
- custom disk usage text with font size adjustment, multi-line support, line-height adjustment, and more
- fully reorderable text layout using {free}, {used}, and {total} tokens, with independent bold toggles
  for each value

ex.
100GB free | 100GB/200GB
*/
// ==/WindhawkModReadme==

// ==WindhawkModSettings==
/*
- useAccentColor: false
  $name: Follow System Accent Color
  $description: Uses the system accent color for the disk usage bar gradient. Disable to use custom colors below
- accentColorGradientDelta: 15
  $name: Accent Color Gradient Delta (%)
  $description: How strong the gradient appears. Set to 0 for a solid color.
- barNormalStart: "#FF2ECC71"
  $name: Disk Bar Color Gradient Start
  $description: set start and end to the same value if you do not want a gradient
- barNormalEnd: "#FF27AE60"
  $name: Disk Bar Color Gradient End
- barFullStart: "#FFE74C3C"
  $name: Disk Bar Full Color Gradient Start
- barFullEnd: "#FFC0392B"
  $name: Disk Bar Full Color Gradient End
- gradientDirection: 90
  $name: Gradient Direction
- cornerRadius: 24
  $name: Corner Radius (Quarter Pixels)
  $description: Set corner radius in quarter pixels. Ex. 41 = 10.25px, 22 = 5.5px
- roundFillBothSides: true
  $name: Round Both Sides of Fill
  $description: If enabled, both sides of the progress bar will be rounded. If disabled, the right side will be flat unless full.   
- showGloss: true
  $name: Enable Glossy Overlay
- fillPadding: 0
  $name: Disk Bar Fill Padding (Quarter Pixels)
  $description: Extra space between the progress fill and the track border in quarter pixels.  
- leftInset: 0
  $name: Disk Bar Inset Left
- rightInset: 0
  $name: Disk Bar Inset Right
- topInset: 0
  $name: Disk Bar Inset Top
- bottomInset: 0
  $name: Disk Bar Inset Bottom
- barYOffset: 0
  $name: Disk Bar Vertical Offset  
- trackColor: "#20000000" 
  $name: Track Color (Unused Space)  
- trackLeftInset: 0
  $name: Track Inset Left
- trackRightInset: 0
  $name: Track Inset Right
- trackTopInset: 0
  $name: Track Inset Top
- trackBottomInset: 0
  $name: Track Inset Bottom
- borderColor: "#80BBBBBB"
  $name: Border Color
- borderThickness: 4
  $name: Border Thickness (Quarter Pixels)
  $description: Border thickness in quarter pixels
- trackBorderOffset: 0
  $name: Border Offset (Quarter Pixels)
  $description: Adjusts the border position relative to the track in quarter pixels. Positive values expand outwards.
- formatString: "{free} free | {used} used\\n{total} total"
  $name: Text Display Format
  $description: >-
    Use {free}, {used}, and {total} anywhere and in any order to control both
    the content AND the position of each value. Use \n for a new line. Ex:
    "{total} total\n{free} free - {used} used" puts total first.
- boldFree: false
  $name: Bold Free Space Value
- boldUsed: true
  $name: Bold Used Space Value
- boldTotal: false
  $name: Bold Total Space Value
- boldStyle: sans-serif
  $name: Text Style
  $options:
    - serif: Serif
    - sans-serif: Sans-Serif
- removeSpace: false
  $name: Remove Space before Units (100GB/100 GB)
- lineYOffset: 0
  $name: Text Vertical Offset
- lineSpacing: 0
  $name: Line Height
  $description: Adjusts the vertical space between lines of text
- fontSize: 0
  $name: Font Size (Quarter Pixels)
  $description: Adjusts the font size (positive is larger, negative is smaller) in quarter pixels. Ex. 4 = +1px, -2 = -0.5px.
- enableWordEllipsis: false
  $name: Enable Word Ellipsis
  $description: (Adds "..." if text is too long)
*/
// ==/WindhawkModSettings==

#include <commctrl.h>
#include <gdiplus.h>
#include <shlobj.h>
#include <shlwapi.h>
#include <uxtheme.h>
#include <windhawk_api.h>
#include <windows.h>
#include <algorithm>
#include <cwchar>
#include <shared_mutex>
#include <string>
#include <unordered_map>
#include <vector>

using namespace Gdiplus;

// --- Global State ---
enum class BoldStyle { Serif, SansSerif };
std::wstring g_formatString;
bool g_boldFree, g_boldUsed, g_boldTotal, g_removeSpace, g_showGloss,
    g_enableWordEllipsis, g_roundFillBothSides, g_useAccentColor;
int g_lineYOffset, g_accentColorGradientDelta;
DWORD g_lastAccentColor = 0;
int g_barYOffset, g_lineSpacing;
int g_leftInset, g_rightInset, g_topInset, g_bottomInset;
int g_trackLeftInset, g_trackRightInset, g_trackTopInset, g_trackBottomInset;
int g_gradientDirection;
ARGB g_barNormalStart, g_barNormalEnd, g_barFullStart, g_barFullEnd,
    g_trackColor, g_borderColor;
float g_borderThickness, g_trackBorderOffset, g_fillPadding, g_cornerRadius,
    g_fontSize;
BoldStyle g_boldStyle;
ULONG_PTR g_gdiplusToken;

typedef int(WINAPI* DrawTextW_t)(HDC hdc,
                                 LPCWSTR lpchText,
                                 int cchText,
                                 LPRECT lprc,
                                 UINT format);
DrawTextW_t DrawTextW_Orig;
typedef int(WINAPI* DrawTextExW_t)(HDC hdc,
                                   LPWSTR lpchText,
                                   int cchText,
                                   LPRECT lprc,
                                   UINT format,
                                   LPDRAWTEXTPARAMS lpdtp);
DrawTextExW_t DrawTextExW_Orig;
typedef HRESULT(WINAPI* DrawThemeBackground_t)(HTHEME hTheme,
                                               HDC hdc,
                                               int iPartId,
                                               int iStateId,
                                               LPCRECT pRect,
                                               LPCRECT pClipRect);
DrawThemeBackground_t DrawThemeBackground_Orig;

typedef HWND(WINAPI* GetThemeWindow_t)(HTHEME hTheme);
GetThemeWindow_t GetThemeWindow_Ptr;
typedef HRESULT(WINAPI* GetThemeClassList_t)(HTHEME hTheme,
                                             LPWSTR pszClassList,
                                             int cchClassList);
GetThemeClassList_t GetThemeClassList_Ptr;

std::shared_mutex g_themeClassMutex;
std::unordered_map<HTHEME, std::wstring> g_themeClasses;

typedef HTHEME(WINAPI* OpenThemeData_t)(HWND hwnd, LPCWSTR pszClassList);
OpenThemeData_t OpenThemeData_Orig;
HTHEME WINAPI OpenThemeData_Hook(HWND hwnd, LPCWSTR pszClassList) {
    HTHEME hTheme = OpenThemeData_Orig(hwnd, pszClassList);
    if (hTheme && pszClassList) {
        std::unique_lock lock(g_themeClassMutex);
        g_themeClasses[hTheme] = pszClassList;
    }
    return hTheme;
}

typedef HTHEME(WINAPI* OpenThemeDataEx_t)(HWND hwnd,
                                          LPCWSTR pszClassList,
                                          DWORD dwFlags);
OpenThemeDataEx_t OpenThemeDataEx_Orig;
HTHEME WINAPI OpenThemeDataEx_Hook(HWND hwnd,
                                   LPCWSTR pszClassList,
                                   DWORD dwFlags) {
    HTHEME hTheme = OpenThemeDataEx_Orig(hwnd, pszClassList, dwFlags);
    if (hTheme && pszClassList) {
        std::unique_lock lock(g_themeClassMutex);
        g_themeClasses[hTheme] = pszClassList;
    }
    return hTheme;
}

typedef HTHEME(WINAPI* OpenThemeDataForDpi_t)(HWND hwnd,
                                              LPCWSTR pszClassList,
                                              UINT dpi);
OpenThemeDataForDpi_t OpenThemeDataForDpi_Orig;
HTHEME WINAPI OpenThemeDataForDpi_Hook(HWND hwnd,
                                       LPCWSTR pszClassList,
                                       UINT dpi) {
    HTHEME hTheme = OpenThemeDataForDpi_Orig(hwnd, pszClassList, dpi);
    if (hTheme && pszClassList) {
        std::unique_lock lock(g_themeClassMutex);
        g_themeClasses[hTheme] = pszClassList;
    }
    return hTheme;
}

typedef HRESULT(WINAPI* CloseThemeData_t)(HTHEME hTheme);
CloseThemeData_t CloseThemeData_Orig;
HRESULT WINAPI CloseThemeData_Hook(HTHEME hTheme) {
    if (hTheme) {
        std::unique_lock lock(g_themeClassMutex);
        g_themeClasses.erase(hTheme);
    }
    return CloseThemeData_Orig(hTheme);
}

// --- Helpers ---
static ARGB ParseHexARGB(PCWSTR hex, ARGB fallback) {
    if (!hex || wcslen(hex) < 1)
        return fallback;
    std::wstring s(hex);
    if (s[0] == L'#')
        s = s.substr(1);
    try {
        unsigned long val = std::stoul(s, nullptr, 16);
        if (s.length() == 6)
            val |= 0xFF000000;
        return (ARGB)val;
    } catch (...) {
        return fallback;
    }
}

void RefreshAccentColorIfNeeded() {
    if (!g_useAccentColor)
        return;
    DWORD color = 0;
    DWORD size = sizeof(DWORD);
    if (RegGetValueW(HKEY_CURRENT_USER, L"Software\\Microsoft\\Windows\\DWM",
                     L"ColorizationColor", RRF_RT_DWORD, nullptr, &color,
                     &size) == ERROR_SUCCESS) {
        color |= 0xFF000000;
        if (color != g_lastAccentColor) {
            g_lastAccentColor = color;
            g_barNormalStart = color;

            float multiplier =
                1.0f - ((float)g_accentColorGradientDelta / 100.0f);
            if (multiplier < 0.0f)
                multiplier = 0.0f;
            if (multiplier > 1.0f)
                multiplier = 1.0f;

            BYTE a = (color >> 24) & 0xFF;
            BYTE r = (BYTE)(((color >> 16) & 0xFF) * multiplier);
            BYTE g = (BYTE)(((color >> 8) & 0xFF) * multiplier);
            BYTE b = (BYTE)((color & 0xFF) * multiplier);

            g_barNormalEnd = (a << 24) | (r << 16) | (g << 8) | b;
        }
    }
}

void LoadSettings() {
    PCWSTR s;
    s = Wh_GetStringSetting(L"barNormalStart");
    g_barNormalStart = ParseHexARGB(s, 0xFF2ECC71);
    Wh_FreeStringSetting(s);
    s = Wh_GetStringSetting(L"barNormalEnd");
    g_barNormalEnd = ParseHexARGB(s, 0xFF27AE60);
    Wh_FreeStringSetting(s);
    s = Wh_GetStringSetting(L"barFullStart");
    g_barFullStart = ParseHexARGB(s, 0xFFE74C3C);
    Wh_FreeStringSetting(s);
    s = Wh_GetStringSetting(L"barFullEnd");
    g_barFullEnd = ParseHexARGB(s, 0xFFC0392B);
    Wh_FreeStringSetting(s);
    s = Wh_GetStringSetting(L"trackColor");
    g_trackColor = ParseHexARGB(s, 0x20000000);
    Wh_FreeStringSetting(s);
    s = Wh_GetStringSetting(L"borderColor");
    g_borderColor = ParseHexARGB(s, 0x80FFFFFF);
    Wh_FreeStringSetting(s);
    g_gradientDirection = Wh_GetIntSetting(L"gradientDirection");
    g_cornerRadius = (float)Wh_GetIntSetting(L"cornerRadius") / 4.0f;
    g_showGloss = Wh_GetIntSetting(L"showGloss") != 0;
    g_roundFillBothSides = Wh_GetIntSetting(L"roundFillBothSides") != 0;
    g_borderThickness = (float)Wh_GetIntSetting(L"borderThickness") / 4.0f;
    g_trackBorderOffset = (float)Wh_GetIntSetting(L"trackBorderOffset") / 4.0f;
    g_fillPadding = (float)Wh_GetIntSetting(L"fillPadding") / 4.0f;
    g_leftInset = Wh_GetIntSetting(L"leftInset");
    g_rightInset = Wh_GetIntSetting(L"rightInset");
    g_topInset = Wh_GetIntSetting(L"topInset");
    g_bottomInset = Wh_GetIntSetting(L"bottomInset");
    g_trackLeftInset = Wh_GetIntSetting(L"trackLeftInset");
    g_trackRightInset = Wh_GetIntSetting(L"trackRightInset");
    g_trackTopInset = Wh_GetIntSetting(L"trackTopInset");
    g_trackBottomInset = Wh_GetIntSetting(L"trackBottomInset");

    s = Wh_GetStringSetting(L"formatString");

    if (s && s[0] != L'\0') {
        g_formatString = s;
    } else {
        g_formatString = L"{free} free | {used} used\n{total} total";
    }
    Wh_FreeStringSetting(s);
    size_t pos = 0;
    while ((pos = g_formatString.find(L"\\n", pos)) != std::wstring::npos) {
        g_formatString.replace(pos, 2, L"\n");
        pos += 1;
    }
    // If the custom format string doesn't contain any recognized tokens,
    // fall back to the default layout so text doesn't silently disappear.
    if (g_formatString.find(L"{free}") == std::wstring::npos &&
        g_formatString.find(L"{used}") == std::wstring::npos &&
        g_formatString.find(L"{total}") == std::wstring::npos) {
        g_formatString = L"{free} free | {used} used\n{total} total";
    }

    g_boldFree = Wh_GetIntSetting(L"boldFree") != 0;
    g_boldUsed = Wh_GetIntSetting(L"boldUsed") != 0;
    g_boldTotal = Wh_GetIntSetting(L"boldTotal") != 0;
    g_removeSpace = Wh_GetIntSetting(L"removeSpace") != 0;
    g_enableWordEllipsis = Wh_GetIntSetting(L"enableWordEllipsis") != 0;
    s = Wh_GetStringSetting(L"boldStyle");
    g_boldStyle = (s && wcscmp(s, L"serif") == 0) ? BoldStyle::Serif
                                                  : BoldStyle::SansSerif;
    Wh_FreeStringSetting(s);
    g_lineYOffset = Wh_GetIntSetting(L"lineYOffset");
    g_barYOffset = Wh_GetIntSetting(L"barYOffset");
    g_lineSpacing = Wh_GetIntSetting(L"lineSpacing");
    g_fontSize = (float)Wh_GetIntSetting(L"fontSize") / 4.0f;
    g_useAccentColor = Wh_GetIntSetting(L"useAccentColor") != 0;
    g_accentColorGradientDelta = Wh_GetIntSetting(L"accentColorGradientDelta");

    g_lastAccentColor = 0;
    if (g_useAccentColor) {
        RefreshAccentColorIfNeeded();
    }
}

std::wstring CleanNumericString(const std::wstring& s) {
    std::wstring result;
    bool start = false;
    for (wchar_t c : s) {
        wchar_t check = (c == 0xA0) ? L' ' : c;
        if (!start) {
            if (iswdigit(check) || check == L'.' || check == L',' ||
                check == L'-') {
                start = true;
                result += (check == L',') ? L'.' : check;
            }
            continue;
        }
        if (check != L' ')
            result += (check == L',') ? L'.' : check;
    }
    return result;
}

bool IsValidUnitString(const wchar_t* u) {
    size_t len = wcslen(u);
    if (len == 0 || len > 10)
        return false;

    std::wstring up = u;
    std::transform(up.begin(), up.end(), up.begin(), ::towupper);

    if (up == L"B" || up == L"KB" || up == L"MB" || up == L"GB" ||
        up == L"TB" || up == L"PB" || up == L"EB")
        return true;
    if (up == L"O" || up == L"KO" || up == L"MO" || up == L"GO" ||
        up == L"TO" || up == L"PO" || up == L"EO")
        return true;
    if (up == L"\x0411" || up == L"\x041A\x0411" || up == L"\x041C\x0411" ||
        up == L"\x0413\x0411" || up == L"\x0422\x0411" || up == L"\x041F\x0411")
        return true;
    if (up == L"BYTES" || up == L"BYTE")
        return true;
    if (up.find(L"\x0411\x0410\x0419\x0422") != std::wstring::npos)
        return true;

    if (len <= 2) {
        for (size_t i = 0; i < len; ++i) {
            if (!iswalpha(u[i]))
                return false;
        }
        return true;
    }

    return false;
}

double GetUnitMultiplier(const wchar_t* u) {
    std::wstring up = u;
    std::transform(up.begin(), up.end(), up.begin(), ::towupper);

    wchar_t prefix = 0;
    for (wchar_t c : up) {
        if (c != L' ' && c != L'.' && c != L',') {
            prefix = c;
            break;
        }
    }

    if (prefix == L'T' || prefix == L'\x0422')
        return 1099511627776.0;
    if (prefix == L'G' || prefix == L'\x0413')
        return 1073741824.0;
    if (prefix == L'M' || prefix == L'\x041C')
        return 1048576.0;
    if (prefix == L'K' || prefix == L'\x041A')
        return 1024.0;
    if (prefix == L'B' || prefix == L'\x0411' || prefix == L'O')
        return 1.0;

    return 0.0;
}

std::wstring MakeBoldText(const std::wstring& s) {
    std::wstring res;
    for (wchar_t c : s) {
        if (c >= L'0' && c <= L'9') {
            res += (wchar_t)0xD835;
            res +=
                (wchar_t)((g_boldStyle == BoldStyle::Serif ? 0xDFCE : 0xDFEC) +
                          (c - L'0'));
        } else if (c >= L'A' && c <= L'Z') {
            res += (wchar_t)0xD835;
            res +=
                (wchar_t)((g_boldStyle == BoldStyle::Serif ? 0xDC00 : 0xDDD4) +
                          (c - L'A'));
        } else if (c >= L'a' && c <= L'z') {
            res += (wchar_t)0xD835;
            res +=
                (wchar_t)((g_boldStyle == BoldStyle::Serif ? 0xDC1A : 0xDDEE) +
                          (c - L'a'));
        } else
            res += c;
    }
    return res;
}

// Replaces every occurrence of `token` in `s` with `value`. Advances past
// the inserted value so we don't re-scan replacement text for tokens.
static void ReplaceAllTokens(std::wstring& s,
                             const std::wstring& token,
                             const std::wstring& value) {
    size_t pos = 0;
    while ((pos = s.find(token, pos)) != std::wstring::npos) {
        s.replace(pos, token.length(), value);
        pos += value.length();
    }
}

// Builds the final display string from g_formatString, substituting
// {free}, {used}, and {total} in whatever order/positions the user placed
// them, applying each value's independent bold setting.
std::wstring BuildFormattedText(const std::wstring& freeStr,
                                const std::wstring& usedStr,
                                const std::wstring& totalStr) {
    std::wstring result = g_formatString;
    ReplaceAllTokens(result, L"{free}",
                     g_boldFree ? MakeBoldText(freeStr) : freeStr);
    ReplaceAllTokens(result, L"{used}",
                     g_boldUsed ? MakeBoldText(usedStr) : usedStr);
    ReplaceAllTokens(result, L"{total}",
                     g_boldTotal ? MakeBoldText(totalStr) : totalStr);
    return result;
}

static bool IsValidDiskBarWindow(HWND hwnd) {
    if (!hwnd) {
        // WindowFromDC can return NULL for memory DCs (used in double
        // buffering). We must return true to allow drawing to these off-screen
        // buffers.
        return true;
    }
    HWND walk = hwnd;
    int limit = 15;
    while (walk && limit-- > 0) {
        wchar_t cls[MAX_PATH];
        if (GetClassNameW(walk, cls, MAX_PATH)) {
            std::wstring wCls(cls);
            std::transform(wCls.begin(), wCls.end(), wCls.begin(), ::towlower);

            if (wCls == L"#32770" || wCls == L"msctls_progress32" ||
                wCls.find(L"scrollbar") != std::wstring::npos ||
                wCls.find(L"header") != std::wstring::npos ||
                wCls.find(L"listview") != std::wstring::npos ||
                wCls.find(L"treeview") != std::wstring::npos ||
                wCls.find(L"toolbar") != std::wstring::npos ||
                wCls.find(L"breadcrumb") != std::wstring::npos ||
                wCls.find(L"address") != std::wstring::npos ||
                (wCls.find(L"property") != std::wstring::npos &&
                 wCls.find(L"propertycontrol") == std::wstring::npos)) {
                return false;
            }
            if (wCls == L"directuihwnd") {
                return true;  // Fast exit if we hit the valid container
            }
        }
        walk = GetParent(walk);
    }
    return true;
}

thread_local static HDC g_lastBarDC = NULL;
thread_local static RECT g_lastBarRect = {0};

static void BuildRoundedPath(GraphicsPath& path,
                             RectF rect,
                             float radius,
                             bool rL = true,
                             bool rR = true) {
    path.Reset();
    float d = std::min(radius * 2.0f, rect.Height);
    if (d < 1.0f) {
        path.AddRectangle(rect);
        return;
    }

    float x = rect.X;
    float y = rect.Y;
    float w = rect.Width;
    float h = rect.Height;

    path.StartFigure();

    // Top-left
    if (rL) {
        path.AddArc(x, y, d, d, 180, 90);
    } else {
        path.AddLine(x, y + radius, x, y);
        path.AddLine(x, y, x + radius, y);
    }

    // Top-right
    if (rR) {
        path.AddArc(x + w - d, y, d, d, 270, 90);
    } else {
        path.AddLine(x + w - radius, y, x + w, y);
        path.AddLine(x + w, y, x + w, y + radius);
    }

    // Bottom-right
    if (rR) {
        path.AddArc(x + w - d, y + h - d, d, d, 0, 90);
    } else {
        path.AddLine(x + w, y + h - radius, x + w, y + h);
        path.AddLine(x + w, y + h, x + w - radius, y + h);
    }

    // Bottom-left
    if (rL) {
        path.AddArc(x, y + h - d, d, d, 90, 90);
    } else {
        path.AddLine(x + radius, y + h, x, y + h);
        path.AddLine(x, y + h, x, y + h - radius);
    }
    path.CloseFigure();
}

static void PaintEnhancedBar(HDC hdc,
                             LPCRECT pRect,
                             LPCRECT pClipRect,
                             int iStateId,
                             bool isFill) {
    if (g_useAccentColor) {
        RefreshAccentColorIfNeeded();
    }
    float scale = 1.0f;
    static auto pGetDpiForWindow = (UINT(WINAPI*)(HWND))GetProcAddress(
        GetModuleHandleW(L"user32.dll"), "GetDpiForWindow");

    HWND hwnd = WindowFromDC(hdc);
    if (pGetDpiForWindow && hwnd) {
        scale = (float)pGetDpiForWindow(hwnd) / 96.0f;
    } else {
        scale = (float)GetDeviceCaps(hdc, LOGPIXELSY) / 96.0f;
    }

    Graphics graphics{hdc};
    if (pClipRect) {
        graphics.SetClip(Rect(pClipRect->left, pClipRect->top,
                              pClipRect->right - pClipRect->left,
                              pClipRect->bottom - pClipRect->top));
    }

    graphics.SetSmoothingMode(SmoothingModeAntiAlias);
    graphics.SetPixelOffsetMode(PixelOffsetModeHighQuality);

    RectF barRect{(REAL)pRect->left, (REAL)pRect->top,
                  (REAL)(pRect->right - pRect->left),
                  (REAL)(pRect->bottom - pRect->top)};

    barRect.Y += (float)g_barYOffset;

    // 1. Calculate Track Geometry (The container)
    // We try to derive the track from g_lastBarRect to ensure the Fill pass
    // knows the full width for rounding its right side.
    RectF trackRect;
    if (isFill && g_lastBarRect.right > g_lastBarRect.left) {
        trackRect.X = (float)g_lastBarRect.left;
        trackRect.Y = (float)g_lastBarRect.top;
        trackRect.Width = (float)(g_lastBarRect.right - g_lastBarRect.left);
        trackRect.Height = (float)(g_lastBarRect.bottom - g_lastBarRect.top);
        trackRect.Y += (float)g_barYOffset;
    } else {
        trackRect = barRect;
    }

    trackRect.X += (float)g_trackLeftInset * scale;
    trackRect.Y += (float)g_trackTopInset * scale;
    trackRect.Width -= (float)(g_trackLeftInset + g_trackRightInset) * scale;
    trackRect.Height -= (float)(g_trackTopInset + g_trackBottomInset) * scale;

    if (trackRect.Width <= 0.1f || trackRect.Height <= 0.1f)
        return;

    // 2. Paths
    GraphicsPath trackPath;
    BuildRoundedPath(trackPath, trackRect, (float)g_cornerRadius * scale);

    RectF borderRect = trackRect;
    float bOff = g_trackBorderOffset * scale;
    if (bOff != 0) {
        borderRect.Inflate(bOff, bOff);
    }
    GraphicsPath borderPath;
    BuildRoundedPath(borderPath, borderRect, (float)g_cornerRadius * scale);

    if (!isFill) {
        // PASS A: Background
        SolidBrush trBr{Color{g_trackColor}};
        graphics.FillPath(&trBr, &trackPath);

        if (((g_borderColor >> 24) & 0xFF) > 0 && g_borderThickness > 0.01f) {
            Pen p{Color{g_borderColor}, g_borderThickness * scale};
            p.SetAlignment(PenAlignmentCenter);
            graphics.DrawPath(&p, &borderPath);
        }
    } else {
        // PASS B: Fill

        RectF fillRect = barRect;
        fillRect.X += (float)g_leftInset * scale;
        fillRect.Y += (float)g_topInset * scale;
        fillRect.Width -= (float)(g_leftInset + g_rightInset) * scale;
        fillRect.Height -= (float)(g_topInset + g_bottomInset) * scale;

        float fPad = g_fillPadding * scale;
        if (fPad != 0) {
            fillRect.Inflate(-fPad, -fPad);
        }

        if (fillRect.Width > 0.1f && fillRect.Height > 0.1f) {
            bool rR = g_roundFillBothSides;
            if (!rR) {
                // If fill reaches roughly the right side of the track, round it
                // too
                if (pRect->right >= g_lastBarRect.right - (int)(1 * scale)) {
                    rR = true;
                }
            }

            GraphicsPath fillPath;
            BuildRoundedPath(fillPath, fillRect, (float)g_cornerRadius * scale,
                             true, rR);

            ARGB c1 = (iStateId == 2) ? g_barFullStart : g_barNormalStart;
            ARGB c2 = (iStateId == 2) ? g_barFullEnd : g_barNormalEnd;
            RectF gradRect = fillRect;
            gradRect.Inflate(0.5f, 0.5f);
            LinearGradientBrush br{gradRect, Color{c1}, Color{c2},
                                   (REAL)g_gradientDirection};
            br.SetWrapMode(WrapModeTileFlipXY);
            graphics.FillPath(&br, &fillPath);

            if (g_showGloss) {
                graphics.SetClip(&fillPath);
                RectF gRect = fillRect;
                gRect.Y += 1.0f;
                gRect.Height -= 2.0f;
                gRect.Height = fmax(gRect.Height / 2.0f, 0.5f);
                LinearGradientBrush gBr{gRect, Color{142, 255, 255, 255},
                                        Color{0, 255, 255, 255}, 90.0f};
                gBr.SetWrapMode(WrapModeTileFlipXY);
                graphics.FillRectangle(&gBr, gRect);
                graphics.ResetClip();
            }
        }
    }
}

static bool IsDiskBar(HTHEME hTheme,
                      HDC hdc,
                      int iPartId,
                      int iStateId,
                      LPCRECT pRect,
                      bool logMismatches = false) {
    if (!pRect) {
        if (logMismatches)
            Wh_Log(L"IsDiskBar: FAILED because pRect is NULL");
        return false;
    }
    if (iPartId != 1 && iPartId != 5 && iPartId != 11) {
        if (logMismatches)
            Wh_Log(
                L"IsDiskBar: FAILED because iPartId is %d (must be 1, 5, or "
                L"11)",
                iPartId);
        return false;
    }

    HWND hwnd = NULL;
    if (GetThemeWindow_Ptr)
        hwnd = GetThemeWindow_Ptr(hTheme);
    if (!hwnd)
        hwnd = WindowFromDC(hdc);
    if (!hwnd)
        hwnd = GetActiveWindow();

    static auto pGetDpiForWindow = (UINT(WINAPI*)(HWND))GetProcAddress(
        GetModuleHandleW(L"user32.dll"), "GetDpiForWindow");
    float scale = 1.0f;
    if (pGetDpiForWindow && hwnd) {
        scale = (float)pGetDpiForWindow(hwnd) / 96.0f;
    } else {
        // Fallback
        scale = (float)GetDeviceCaps(hdc, LOGPIXELSY) / 96.0f;
    }

    // Logical Dimensioning
    int h = pRect->bottom - pRect->top;
    int w = pRect->right - pRect->left;

    // Normalize physical pixels to logical bounds
    float logicalH = (float)h / scale;
    float logicalW = (float)w / scale;

    if (iPartId == 5) {
        if (logicalH < 2.0f || logicalH > 16.5f) {
            if (logMismatches)
                Wh_Log(
                    L"IsDiskBar: FAILED Part 5 because logicalH=%f is out of "
                    L"bounds [2.0, 16.5]",
                    logicalH);
            return false;
        }
    } else {
        if (logicalW < 30.0f) {
            if (logMismatches)
                Wh_Log(L"IsDiskBar: FAILED because logicalW=%f < 30.0",
                       logicalW);
            return false;
        }
        if (logicalH < 4.0f || logicalH > 16.5f) {
            if (logMismatches)
                Wh_Log(
                    L"IsDiskBar: FAILED because logicalH=%f is out of bounds "
                    L"[4.0, 16.5]",
                    logicalH);
            return false;
        }
    }

    if (GetThemeClassList_Ptr) {
        wchar_t themeCls[256];
        if (SUCCEEDED(GetThemeClassList_Ptr(hTheme, themeCls, 256))) {
            std::wstring tCls(themeCls);
            std::transform(tCls.begin(), tCls.end(), tCls.begin(), ::towlower);
            if (tCls.find(L"progress") == std::wstring::npos) {
                if (logMismatches)
                    Wh_Log(
                        L"IsDiskBar: FAILED because Theme Class List '%s' does "
                        L"not contain 'progress'",
                        themeCls);
                return false;
            }
            if (tCls.find(L"scrollbar") != std::wstring::npos ||
                tCls.find(L"header") != std::wstring::npos) {
                if (logMismatches)
                    Wh_Log(
                        L"IsDiskBar: FAILED because Theme Class List '%s' "
                        L"contains 'scrollbar' or 'header'",
                        themeCls);
                return false;
            }
        }
    }

    bool isPropertyControl = false;
    if (hwnd) {
        HWND walk = hwnd;
        int limit = 15;
        while (walk && limit-- > 0) {
            wchar_t cls[MAX_PATH];
            if (GetClassNameW(walk, cls, MAX_PATH)) {
                std::wstring wCls(cls);
                std::transform(wCls.begin(), wCls.end(), wCls.begin(),
                               ::towlower);

                if (wCls.find(L"propertycontrol") != std::wstring::npos) {
                    isPropertyControl = true;
                }

                if (wCls == L"#32770" || wCls == L"msctls_progress32" ||
                    wCls.find(L"scrollbar") != std::wstring::npos ||
                    wCls.find(L"header") != std::wstring::npos ||
                    wCls.find(L"listview") != std::wstring::npos ||
                    wCls.find(L"treeview") != std::wstring::npos ||
                    wCls.find(L"toolbar") != std::wstring::npos ||
                    wCls.find(L"breadcrumb") != std::wstring::npos ||
                    wCls.find(L"address") != std::wstring::npos ||
                    (wCls.find(L"property") != std::wstring::npos &&
                     wCls.find(L"propertycontrol") == std::wstring::npos)) {
                    if (logMismatches)
                        Wh_Log(
                            L"IsDiskBar: FAILED due to excluded parent window "
                            L"class: '%s'",
                            cls);
                    return false;
                }
            }
            walk = GetParent(walk);
        }
    }

    // prevent navpane being styled
    if (!isPropertyControl && pRect->left < (int)(32 * scale)) {
        if (logMismatches)
            Wh_Log(L"IsDiskBar: FAILED because pRect->left (%d) < 32 * scale",
                   pRect->left);
        return false;
    }
    return true;
}

// (Globals removed from here)

HRESULT WINAPI HookedDrawThemeBackground(HTHEME hTheme,
                                         HDC hdc,
                                         int iPartId,
                                         int iStateId,
                                         LPCRECT pRect,
                                         LPCRECT pClipRect) {
    bool isProgressSize = false;
    if (pRect) {
        int h = pRect->bottom - pRect->top;
        int w = pRect->right - pRect->left;
        if (h >= 3 && h <= 35 && w >= 15) {
            isProgressSize = true;
        }
    }

    if (isProgressSize) {
        wchar_t themeCls[256] = L"Unknown";
        if (GetThemeClassList_Ptr) {
            GetThemeClassList_Ptr(hTheme, themeCls, 256);
        }
        wchar_t parentCls[256] = L"None";
        HWND hwnd = NULL;
        if (GetThemeWindow_Ptr)
            hwnd = GetThemeWindow_Ptr(hTheme);
        if (!hwnd)
            hwnd = WindowFromDC(hdc);
        if (hwnd)
            GetClassNameW(hwnd, parentCls, 256);

        bool isDisk = IsDiskBar(hTheme, hdc, iPartId, iStateId, pRect, false);
        if (!isDisk) {
            Wh_Log(L"--- HookedDrawThemeBackground (Potential Disk Bar) ---");
            Wh_Log(
                L"PartID=%d, StateID=%d, Rect=[l:%d, t:%d, r:%d, b:%d] (w=%d, "
                L"h=%d), Class='%s', ParentWindow='%s'",
                iPartId, iStateId, pRect->left, pRect->top, pRect->right,
                pRect->bottom, pRect->right - pRect->left,
                pRect->bottom - pRect->top, themeCls, parentCls);
            // Run again with logging enabled to print the precise mismatch
            IsDiskBar(hTheme, hdc, iPartId, iStateId, pRect, true);
        } else {
            Wh_Log(
                L"IsDiskBar MATCH: PartID=%d, StateID=%d, Rect=[l:%d, t:%d, "
                L"r:%d, b:%d] (w=%d, h=%d), Class='%s'",
                iPartId, iStateId, pRect->left, pRect->top, pRect->right,
                pRect->bottom, pRect->right - pRect->left,
                pRect->bottom - pRect->top, themeCls);
        }
    }

    if (IsDiskBar(hTheme, hdc, iPartId, iStateId, pRect, false)) {
        bool first = !(hdc == g_lastBarDC && EqualRect(pRect, &g_lastBarRect));

        if (iPartId == 5) {
            // Fill
            PaintEnhancedBar(hdc, pRect, pClipRect, iStateId, true);
        } else if (iPartId == 1 || iPartId == 11) {
            // Track / Background
            g_lastBarDC = hdc;
            g_lastBarRect = *pRect;
            if (first)
                PaintEnhancedBar(hdc, pRect, pClipRect, iStateId, false);
        }

        return S_OK;
    }
    return DrawThemeBackground_Orig(hTheme, hdc, iPartId, iStateId, pRect,
                                    pClipRect);
}

bool FindSpaceStats(const std::wstring& t, std::wstring& f, std::wstring& tot) {
    std::wstring nt = t;
    for (auto& c : nt) {
        if (c == 0xA0)
            c = L' ';
    }

    size_t num1_start = nt.find_first_of(L"0123456789");
    if (num1_start == std::wstring::npos)
        return false;

    size_t pos = num1_start;
    while (pos < nt.length() &&
           (iswdigit(nt[pos]) || nt[pos] == L'.' || nt[pos] == L',' ||
            nt[pos] == L' ' || nt[pos] == 0xA0))
        pos++;

    size_t unit1_start = pos;
    while (pos < nt.length() && !iswdigit(nt[pos]) && nt[pos] != L' ')
        pos++;
    size_t size1_end = pos;

    std::wstring u1 = nt.substr(unit1_start, size1_end - unit1_start);
    if (!IsValidUnitString(u1.c_str()))
        return false;

    size_t num2_start = nt.find_first_of(L"0123456789", size1_end);
    if (num2_start == std::wstring::npos)
        return false;

    if (num2_start == size1_end)
        return false;

    pos = num2_start;
    while (pos < nt.length() &&
           (iswdigit(nt[pos]) || nt[pos] == L'.' || nt[pos] == L',' ||
            nt[pos] == L' ' || nt[pos] == 0xA0))
        pos++;

    size_t unit2_start = pos;
    while (pos < nt.length() && !iswdigit(nt[pos]) && nt[pos] != L' ')
        pos++;
    size_t size2_end = pos;

    std::wstring u2 = nt.substr(unit2_start, size2_end - unit2_start);
    if (!IsValidUnitString(u2.c_str()))
        return false;

    // Reject if there is another number after the second unit
    if (nt.find_first_of(L"0123456789", size2_end) != std::wstring::npos) {
        return false;
    }

    f = nt.substr(num1_start, size1_end - num1_start);
    tot = nt.substr(num2_start, size2_end - num2_start);

    while (!f.empty() && f.back() == L' ')
        f.pop_back();
    while (!tot.empty() && tot.back() == L' ')
        tot.pop_back();

    return true;
}

int WINAPI DrawTextW_Hook(HDC hdc, LPCWSTR psz, int cch, LPRECT prc, UINT fmt) {
    if (!psz || !prc)
        return DrawTextW_Orig(hdc, psz, cch, prc, fmt);

    int len = (cch == -1) ? (int)wcslen(psz) : cch;
    bool hasNum = false;
    for (int i = 0; i < len; ++i) {
        if (psz[i] >= L'0' && psz[i] <= L'9') {
            hasNum = true;
            break;
        }
    }
    if (!hasNum)
        return DrawTextW_Orig(hdc, psz, cch, prc, fmt);

    // Target window verification
    if (hdc) {
        HWND hwnd = WindowFromDC(hdc);
        if (!IsValidDiskBarWindow(hwnd)) {
            return DrawTextW_Orig(hdc, psz, cch, prc, fmt);
        }
    }

    std::wstring t(psz, len);
    std::wstring fs, ts;
    if (FindSpaceStats(t, fs, ts)) {
        if (g_removeSpace) {
            fs.erase(std::remove(fs.begin(), fs.end(), L' '), fs.end());
            ts.erase(std::remove(ts.begin(), ts.end(), L' '), ts.end());
        }
        std::wstring cf = CleanNumericString(fs), ct = CleanNumericString(ts);
        double fv, tv;
        wchar_t fu[16], tu[16];

        if (swscanf(cf.c_str(), L"%lf %15s", &fv, fu) == 2 &&
            swscanf(ct.c_str(), L"%lf %15s", &tv, tu) == 2) {
            if (IsValidUnitString(fu) && IsValidUnitString(tu)) {
                double um1 = GetUnitMultiplier(fu);
                double um2 = GetUnitMultiplier(tu);
                if (um1 > 0.0 && um2 > 0.0) {
                    std::wstring us = std::wstring(StrFormatByteSizeW(
                        (ULONGLONG)std::max(0.0, (tv * um2 - fv * um1)), fu,
                        16));

                    if (g_removeSpace)
                        us.erase(std::remove(us.begin(), us.end(), L' '),
                                 us.end());

                    std::wstring ft = BuildFormattedText(fs, us, ts);

                    if (fmt & DT_CALCRECT) {
                        UINT calcFmt = fmt;
                        if (ft.find(L'\n') != std::wstring::npos) {
                            calcFmt &= ~DT_SINGLELINE;
                        }
                        return DrawTextW_Orig(hdc, ft.c_str(), (int)ft.length(),
                                              prc, calcFmt);
                    }

                    int applyLineYOffset = g_lineYOffset;

                    HFONT hOldFont = NULL;
                    HFONT hNewFont = NULL;
                    float scale = (float)GetDeviceCaps(hdc, LOGPIXELSY) / 96.0f;
                    if (g_fontSize != 0.0f) {
                        HFONT hCurrent = (HFONT)GetCurrentObject(hdc, OBJ_FONT);
                        LOGFONTW lf;
                        if (GetObjectW(hCurrent, sizeof(lf), &lf)) {
                            int delta =
                                (int)(g_fontSize * scale +
                                      (g_fontSize >= 0.0f ? 0.5f : -0.5f));
                            if (lf.lfHeight < 0)
                                lf.lfHeight -= delta;
                            else
                                lf.lfHeight += delta;
                            hNewFont = CreateFontIndirectW(&lf);
                            if (hNewFont)
                                hOldFont = (HFONT)SelectObject(hdc, hNewFont);
                        }
                    }

                    bool multiLine = (ft.find(L'\n') != std::wstring::npos);

                    UINT dF = fmt | DT_NOPREFIX;
                    if (!g_enableWordEllipsis) {
                        dF &= ~(DT_END_ELLIPSIS | DT_PATH_ELLIPSIS |
                                DT_WORD_ELLIPSIS);
                    } else {
                        dF |= DT_WORD_ELLIPSIS | DT_END_ELLIPSIS;
                    }
                    RECT r = *prc;
                    r.top += applyLineYOffset;
                    r.bottom += applyLineYOffset;

                    int ft_ret = 0;
                    if (multiLine) {
                        std::vector<std::wstring> lines;
                        size_t start_pos = 0, end_pos = 0;
                        while ((end_pos = ft.find(L'\n', start_pos)) !=
                               std::wstring::npos) {
                            lines.push_back(
                                ft.substr(start_pos, end_pos - start_pos));
                            start_pos = end_pos + 1;
                        }
                        lines.push_back(ft.substr(start_pos));

                        dF &= ~(DT_SINGLELINE | DT_VCENTER | DT_BOTTOM);
                        dF |= DT_TOP | DT_SINGLELINE | DT_NOCLIP | DT_NOPREFIX;

                        int totalHeight = 0;
                        for (size_t i = 0; i < lines.size(); ++i) {
                            RECT lr = r;
                            lr.top += totalHeight;
                            lr.bottom += 1000;
                            if (fmt & DT_CALCRECT) {
                                DrawTextW_Orig(hdc, lines[i].c_str(),
                                               (int)lines[i].length(), &lr,
                                               dF | DT_CALCRECT);
                                totalHeight +=
                                    (lr.bottom - lr.top) + g_lineSpacing;
                            } else {
                                RECT calcR = lr;
                                DrawTextW_Orig(hdc, lines[i].c_str(),
                                               (int)lines[i].length(), &calcR,
                                               dF | DT_CALCRECT);
                                DrawTextW_Orig(hdc, lines[i].c_str(),
                                               (int)lines[i].length(), &lr, dF);
                                totalHeight +=
                                    (calcR.bottom - calcR.top) + g_lineSpacing;
                            }
                        }
                        if (fmt & DT_CALCRECT) {
                            prc->bottom =
                                prc->top + totalHeight - g_lineSpacing;
                        }
                        ft_ret = totalHeight - g_lineSpacing;
                    } else {
                        ft_ret = DrawTextW_Orig(hdc, ft.c_str(),
                                                (int)ft.length(), &r, dF);
                    }

                    if (hOldFont) {
                        SelectObject(hdc, hOldFont);
                        DeleteObject(hNewFont);
                    }
                    return ft_ret;
                }
            }
        }
    }

    return DrawTextW_Orig(hdc, psz, cch, prc, fmt);
}

int WINAPI DrawTextExW_Hook(HDC hdc,
                            LPWSTR psz,
                            int cch,
                            LPRECT prc,
                            UINT fmt,
                            LPDRAWTEXTPARAMS pDtp) {
    if (!psz || !prc)
        return DrawTextExW_Orig(hdc, psz, cch, prc, fmt, pDtp);

    int len = (cch == -1) ? (int)wcslen(psz) : cch;
    bool hasNum = false;
    for (int i = 0; i < len; ++i) {
        if (psz[i] >= L'0' && psz[i] <= L'9') {
            hasNum = true;
            break;
        }
    }
    if (!hasNum)
        return DrawTextExW_Orig(hdc, psz, cch, prc, fmt, pDtp);

    // Target window verification
    if (hdc) {
        HWND hwnd = WindowFromDC(hdc);
        if (!IsValidDiskBarWindow(hwnd)) {
            return DrawTextExW_Orig(hdc, psz, cch, prc, fmt, pDtp);
        }
    }

    std::wstring t(psz, len);
    std::wstring fs, ts;

    if (FindSpaceStats(t, fs, ts)) {
        if (g_removeSpace) {
            fs.erase(std::remove(fs.begin(), fs.end(), L' '), fs.end());
            ts.erase(std::remove(ts.begin(), ts.end(), L' '), ts.end());
        }
        std::wstring cf = CleanNumericString(fs), ct = CleanNumericString(ts);
        double fv, tv;
        wchar_t fu[16], tu[16];

        if (swscanf(cf.c_str(), L"%lf %15s", &fv, fu) == 2 &&
            swscanf(ct.c_str(), L"%lf %15s", &tv, tu) == 2) {
            if (IsValidUnitString(fu) && IsValidUnitString(tu)) {
                double um1 = GetUnitMultiplier(fu);
                double um2 = GetUnitMultiplier(tu);
                if (um1 > 0.0 && um2 > 0.0) {
                    std::wstring us = std::wstring(StrFormatByteSizeW(
                        (ULONGLONG)std::max(0.0, (tv * um2 - fv * um1)), fu,
                        16));

                    if (g_removeSpace)
                        us.erase(std::remove(us.begin(), us.end(), L' '),
                                 us.end());

                    std::wstring ft = BuildFormattedText(fs, us, ts);

                    if (fmt & DT_CALCRECT) {
                        std::vector<wchar_t> b(ft.begin(), ft.end());
                        b.push_back(0);
                        UINT calcFmt = fmt;
                        if (ft.find(L'\n') != std::wstring::npos) {
                            calcFmt &= ~DT_SINGLELINE;
                        }
                        return DrawTextExW_Orig(hdc, b.data(), (int)ft.length(),
                                                prc, calcFmt, pDtp);
                    }

                    int applyLineYOffset = g_lineYOffset;

                    HFONT hOldFont = NULL;
                    HFONT hNewFont = NULL;
                    float scale = (float)GetDeviceCaps(hdc, LOGPIXELSY) / 96.0f;
                    if (g_fontSize != 0.0f) {
                        HFONT hCurrent = (HFONT)GetCurrentObject(hdc, OBJ_FONT);
                        LOGFONTW lf;
                        if (GetObjectW(hCurrent, sizeof(lf), &lf)) {
                            int delta =
                                (int)(g_fontSize * scale +
                                      (g_fontSize >= 0.0f ? 0.5f : -0.5f));
                            if (lf.lfHeight < 0)
                                lf.lfHeight -= delta;
                            else
                                lf.lfHeight += delta;
                            hNewFont = CreateFontIndirectW(&lf);
                            if (hNewFont)
                                hOldFont = (HFONT)SelectObject(hdc, hNewFont);
                        }
                    }

                    bool multiLine = (ft.find(L'\n') != std::wstring::npos);

                    std::vector<wchar_t> b(ft.begin(), ft.end());
                    b.push_back(0);

                    UINT dF = fmt | DT_NOPREFIX;
                    if (!g_enableWordEllipsis) {
                        dF &= ~(DT_END_ELLIPSIS | DT_PATH_ELLIPSIS |
                                DT_WORD_ELLIPSIS);
                    } else {
                        dF |= DT_WORD_ELLIPSIS | DT_END_ELLIPSIS;
                    }
                    RECT r = *prc;
                    r.top += applyLineYOffset;
                    r.bottom += applyLineYOffset;

                    int ft_ret = 0;
                    if (multiLine) {
                        std::vector<std::wstring> lines;
                        size_t start_pos = 0, end_pos = 0;
                        while ((end_pos = ft.find(L'\n', start_pos)) !=
                               std::wstring::npos) {
                            lines.push_back(
                                ft.substr(start_pos, end_pos - start_pos));
                            start_pos = end_pos + 1;
                        }
                        lines.push_back(ft.substr(start_pos));

                        dF &= ~(DT_SINGLELINE | DT_VCENTER | DT_BOTTOM);
                        dF |= DT_TOP | DT_SINGLELINE | DT_NOCLIP | DT_NOPREFIX;

                        int totalHeight = 0;
                        for (size_t i = 0; i < lines.size(); ++i) {
                            RECT lr = r;
                            lr.top += totalHeight;
                            lr.bottom += 1000;
                            std::vector<wchar_t> bl(lines[i].begin(),
                                                    lines[i].end());
                            bl.push_back(0);
                            if (fmt & DT_CALCRECT) {
                                DrawTextExW_Orig(hdc, bl.data(),
                                                 (int)lines[i].length(), &lr,
                                                 dF | DT_CALCRECT, pDtp);
                                totalHeight +=
                                    (lr.bottom - lr.top) + g_lineSpacing;
                            } else {
                                RECT calcR = lr;
                                DrawTextExW_Orig(hdc, bl.data(),
                                                 (int)lines[i].length(), &calcR,
                                                 dF | DT_CALCRECT, pDtp);
                                DrawTextExW_Orig(hdc, bl.data(),
                                                 (int)lines[i].length(), &lr,
                                                 dF, pDtp);
                                totalHeight +=
                                    (calcR.bottom - calcR.top) + g_lineSpacing;
                            }
                        }
                        if (fmt & DT_CALCRECT) {
                            prc->bottom =
                                prc->top + totalHeight - g_lineSpacing;
                        }
                        ft_ret = totalHeight - g_lineSpacing;
                    } else {
                        ft_ret = DrawTextExW_Orig(
                            hdc, b.data(), (int)ft.length(), &r, dF, pDtp);
                    }

                    if (hOldFont) {
                        SelectObject(hdc, hOldFont);
                        DeleteObject(hNewFont);
                    }
                    return ft_ret;
                }
            }
        }
    }

    return DrawTextExW_Orig(hdc, psz, cch, prc, fmt, pDtp);
}

static BOOL CALLBACK RefreshExplorerCallback(HWND hwnd, LPARAM lParam) {
    DWORD dwProcessId;
    GetWindowThreadProcessId(hwnd, &dwProcessId);
    if (dwProcessId != GetCurrentProcessId()) {
        return TRUE;
    }

    wchar_t cls[MAX_PATH];
    if (GetClassNameW(hwnd, cls, MAX_PATH)) {
        if (wcscmp(cls, L"CabinetWClass") == 0) {
            PostMessage(hwnd, WM_COMMAND, 41504, 0);  // Refresh command
            InvalidateRect(hwnd, NULL, TRUE);
        } else if (wcscmp(cls, L"DirectUIHWND") == 0) {
            InvalidateRect(hwnd, NULL, TRUE);
        }
    }
    return TRUE;
}

void RefreshExplorer() {
    EnumWindows(RefreshExplorerCallback, 0);
}

BOOL Wh_ModInit() {
    GdiplusStartupInput gsi;
    GdiplusStartup(&g_gdiplusToken, &gsi, NULL);
    LoadSettings();
    HMODULE uxtheme = GetModuleHandle(L"uxtheme.dll");
    if (uxtheme) {
        GetThemeWindow_Ptr =
            (GetThemeWindow_t)GetProcAddress(uxtheme, "GetThemeWindow");
        GetThemeClassList_Ptr =
            (GetThemeClassList_t)GetProcAddress(uxtheme, "GetThemeClassList");

        Wh_SetFunctionHook((void*)GetProcAddress(uxtheme, "OpenThemeData"),
                           (void*)OpenThemeData_Hook,
                           (void**)&OpenThemeData_Orig);
        Wh_SetFunctionHook((void*)GetProcAddress(uxtheme, "OpenThemeDataEx"),
                           (void*)OpenThemeDataEx_Hook,
                           (void**)&OpenThemeDataEx_Orig);
        Wh_SetFunctionHook((void*)GetProcAddress(uxtheme, "CloseThemeData"),
                           (void*)CloseThemeData_Hook,
                           (void**)&CloseThemeData_Orig);

        Wh_SetFunctionHook(
            (void*)GetProcAddress(uxtheme, "DrawThemeBackground"),
            (void*)HookedDrawThemeBackground,
            (void**)&DrawThemeBackground_Orig);
    }

    if (uxtheme) {
        void* pOpenDpi = (void*)GetProcAddress(uxtheme, "OpenThemeDataForDpi");
        if (pOpenDpi) {
            Wh_SetFunctionHook(pOpenDpi, (void*)OpenThemeDataForDpi_Hook,
                               (void**)&OpenThemeDataForDpi_Orig);
        }
    }

    HMODULE user32 = GetModuleHandle(L"user32.dll");
    if (user32) {
        Wh_SetFunctionHook((void*)GetProcAddress(user32, "DrawTextW"),
                           (void*)DrawTextW_Hook, (void**)&DrawTextW_Orig);
        Wh_SetFunctionHook((void*)GetProcAddress(user32, "DrawTextExW"),
                           (void*)DrawTextExW_Hook, (void**)&DrawTextExW_Orig);
    }
    RefreshExplorer();
    return TRUE;
}

void Wh_ModUninit() {
    GdiplusShutdown(g_gdiplusToken);
    RefreshExplorer();
}
void Wh_ModSettingsChanged() {
    LoadSettings();
    RefreshExplorer();
}